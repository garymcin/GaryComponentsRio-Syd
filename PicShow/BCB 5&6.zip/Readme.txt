PicShow for BCB has been provided by Canonpapago. 

Please forward your questions regarding BCB version of PicShow to canonpapago@yahoo.com.tw

Thank you!