//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
USERES("picshow_bcb5.res");
USEPACKAGE("vcl50.bpi");
USEUNIT("PicShow.pas");
USEUNIT("PSEffect.pas");
USEUNIT("PSReg.pas");
USERES("PSReg.dcr");
USEPACKAGE("vcljpg50.bpi");
USEPACKAGE("Vcldb50.bpi");
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------

//   Package source.
//---------------------------------------------------------------------------

#pragma argsused
int WINAPI DllEntryPoint(HINSTANCE hinst, unsigned long reason, void*)
{
        return 1;
}
//---------------------------------------------------------------------------
